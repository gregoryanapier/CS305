package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.apache.commons.codec.digest.DigestUtils;

@SpringBootApplication
@RestController
public class SslServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(SslServerApplication.class, args);
    }

    @GetMapping("/hash")
    public String myHash() {
        String data = "Artemis Financial Verification: Gregory Napier 6/28/2025";
        return DigestUtils.sha256Hex(data);
    }
}
//FIXME: Add route to enable check sum return of static data example:  String data = "Hello World Check Sum!";